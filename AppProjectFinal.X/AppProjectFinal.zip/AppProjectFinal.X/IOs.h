/*
 * File:   IOs.h
 * Author: randy
 *
 * Created on October 15, 2021, 3:25 PM
 */




#include "TimeDelay.h"

void IOinit();
int IOCheck();
